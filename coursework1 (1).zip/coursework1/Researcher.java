/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package coursework1;

import java.util.List;

/**
 *
 * @author minmm
 */
public class Researcher extends UniversityMember implements StaffMember, AppointmentMaker{ // implements User {
    private StaffProperty staffProperty;
    //private List<String> expertiseList;
    private List<String> appointmentsMade;
    private List<String> expertiseList;
    
    public  Researcher(String [] uniMemAttrs, StaffProperty staffProperty) {
        super(uniMemAttrs, null);
        
        this.staffProperty= staffProperty;
       
    }
    /**
     * @return the classList
     */
    public List<String> getExpertise() {
        return this.staffProperty.getExpertiseList();
    }
    
    public StaffProperty getStaffProperty(){
        return this.staffProperty;
    }
    
    public void printInfo() {
        System.out.println("Researcher Info: " + super.getId()+ " " + super.getLastName() + " " + super.getAddress() + " " + super.getEmail());
        System.out.println("Staff Properties: " + staffProperty.getOffice() + " " + staffProperty.getExpertiseList());
        
    }
   

    @Override
    public boolean makeAppointment(StaffMember staff, String appointment) {
        
        boolean updateavailableAppointments = staff.getStaffProperty().updateAvailableAppointments(appointment);
        System.out.println("staff: " + staff + " : " + appointment );
        System.out.println("update availableAppointments: " + updateavailableAppointments );
        staff.getStaffProperty().addMonthlyAppointmentsBooked(appointment, new String(this.lastName+", "+this.firstName+" ("+this.type+"), University ID: " + this.id));
        
        return true;
    }
    
    @Override
    public List<String> getExpertiseList() {
        expertiseList = this.staffProperty.getExpertiseList();
        return expertiseList;
    }
}
