package coursework1;
/*
 * Lecturer class is a subclass of UniversityMember and it implements StaffMember
 */
import java.util.List;

public class Lecturer extends UniversityMember implements StaffMember {
   
    private StaffProperty staffProperty;
    
    public Lecturer(String [] uniMemAttrs, StaffProperty staffProperty, List<MyClasses> classList) {
        super(uniMemAttrs, classList);
        
        this.staffProperty= staffProperty;
       
    }
        
    public void printInfo() {
        System.out.println("Lecturer info: " + super.getId()+ " " + super.getLastName() + " " + super.getAddress() + " " + super.getEmail());
        System.out.println("Staff Properties: " + staffProperty.getOffice() + " " + staffProperty.getExpertiseList());
        System.out.println("Classed offered: " + classList.get(0).getClassName());
    }
    
     @Override
    public List<String> getExpertiseList() {
        return this.staffProperty.getExpertiseList();
    }
    
    public StaffProperty getStaffProperty(){
        return this.staffProperty;
    }
    
    public void login () {
        System.out.println("Lecturer login: " + super.getId()+ " " + super.getLastName() );
    }
    
    
}