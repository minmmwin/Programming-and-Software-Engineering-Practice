/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package coursework1;

import java.util.Scanner;

/**
 *
 * @author minmm
 */
public class RunMVCThread extends Thread {
    private String message;
    
    public RunMVCThread(String message) {
        this.message = message;
    }
    
     public void run () {  
         System.out.println (message + "\n.......... ");
      //create Model and View
        Model myModel = new Model();
	View myView = new View();
        myView.setVisible(true);
        myView.getStepTwo().setVisible(false);
        myView.getStepThree().setVisible(false);
        myView.getStepFour().setVisible(false);
        myView.getStepFive().setVisible(false);
	
        //tell Model about View. 
	myModel.addObserver(myView);   
         
        //create Controller. tell it about Model and View, initialise model
	Controller myController = new Controller();
	myController.addModel(myModel);
	myController.addView(myView);
	//myController.initModel("Start Model"); 
        
        myView.addController(myController);
        //myView.addGetUserTypeListener(myController.userTypeListener);
            //Fields for userTypeListener
            String userType;
            String id;
            /*String firstName;
            String lastName;
            String fullName;
            String address;
            String email;*/
   /*         Scanner scanner = new Scanner (System.in);
            System.out.print("User type (Teaching Staff / Researcher / Student / Visitor): ");
            userTypeListener = scanner.next();
            
            System.out.print("Enter your id: ");
            id = scanner.next();
            
           */
            
            //System.out.println("UserType: " + userTypeListener + " Name: " + fullName);
            
        //    UserFactory userFactory = new UserFactory();
            
            //get an object of Circle and call its draw method.
         //   User studentUser = userFactory.getUser(userTypeListener, id, fullName);
            
            //call login method of Circle
          //  studentUser.login();
            
     }
    
}
