/*
 * View Class
 */
package coursework1;

import java.awt.*;
import java.awt.event.*;
import java.math.BigInteger;
import java.util.Observable;
import java.util.Observer;
import javax.swing.*;
import javax.swing.border.TitledBorder;

public class View extends JFrame implements Observer {

    // PanelOne fields
    private JButton buttonProf;
    private JButton buttonLecturer;
    private JButton buttonResearcher;
    private JButton buttonStudent;
    private JButton buttonVisitor;
    
    // PanelTwo fields
    private JButton buttonID;
    private JButton buttonVisitorInfo;
    private JTextField chooseID; //1
    private JTextPane resultID; //2
    private JTextField chooseName; //3
    private JTextField chooseEmail; //4
    
    // PanelThree Fields
    private JTextField chooseExpertise; //5
    private JButton buttonExpertise;
    private JTextPane resultSearchExpertise; //6
    private JTextField searchName; //7
    private JButton buttonSearchName;
    private JTextPane resultSearchName; //8
   
    private JLabel classAppointmentList;
    private JTextPane resultExpertiseFour; //9
    private JTextField chooseClass; //10
    private JButton buttonSignUp;
    private JTextPane resultSignUp; //11
    private JLabel classAppointment;
    private JButton buttonExit;
   //private JLabel goodByeLabel;
    
    private JPanel stepOne;
    private JPanel stepTwo;
    private JPanel stepThree;
    private JPanel stepFour;
    private JPanel stepFive;
    
    private JPanel idPanel;
    private JPanel visitorInfoPanel;

  public View () {
    super ("Mont Royal University ");
    setDefaultCloseOperation (JFrame.EXIT_ON_CLOSE);

    setLayout (new GridLayout (1, 4));
    stepOne = makePanelOne ("STEP 1");
    add (stepOne);
    stepTwo = makePanelTwo ("STEP 2");
    //stepTwo.setVisible(false);
    add (stepTwo);
    stepThree = makePanelThree ("STEP 3");
    add (stepThree);
    stepFour = makePanelFour ("STEP 4");
    add (stepFour);
    stepFive = makePanelFive ("STEP 5");
    add (stepFive);
   

    setSize (1400, 600);
  }
  
  /**
     * @return the stepOne
     */
    public JPanel getStepOne() {
        return stepOne;
    }

    /**
     * @return the stepTwo
     */
    public JPanel getStepTwo() {
        return stepTwo;
    }

    /**
     * @return the stepThree
     */
    public JPanel getStepThree() {
        return stepThree;
    }

    /**
     * @return the stepFour
     */
    public JPanel getStepFour() {
        return stepFour;
    }
    
     /**
     * @return the stepFive
     */
    public JPanel getStepFive() {
        return stepFive;
    }
    
     /**
     * @return the idPanel
     */
    public JPanel getIdPanel() {
        return idPanel;
    }

    /**
     * @return the visitorInfoPanel
     */
    public JPanel getVisitorInfoPanel() {
        return visitorInfoPanel;
    }
    
     /**
     * @return the buttonVisitorInfo
     */
    public JButton getButtonVisitorInfo() {
        return buttonVisitorInfo;
    }

  
  public JLabel getClassAppointmentList(){
      return classAppointmentList;
  }
  
  public JLabel getClassAppointment(){
      return classAppointment;
  }
  
  /************
   * RESET TEXT         
   */
   /**
     * @return the resultSignUp
     */
    public JTextPane getResultSignUp() {
        return resultSignUp;
    }

    /**
     * @return the resultExpertiseFour
     */
    public JTextPane getResultExpertiseFour() {
        return resultExpertiseFour;
    }


    /**
     * @return the chooseClass
     */
    public JTextField getChooseClass() {
        return chooseClass;
    }

    /**
     * @return the resultSearchName
     */
    public JTextPane getResultSearchName() {
        return resultSearchName;
    }

    /**
     * @return the resultSearchExpertise
     */
    public JTextPane getResultSearchExpertise() {
        return resultSearchExpertise;
    }

    /**
     * @return the chooseID
     */
    public JTextField getChooseID() {
        return chooseID;
    }
 

    /**
     * @return the resultID
     */
    public JTextPane getResultID() {
        return resultID;
    }


    /**
     * @return the chooseName
     */
    public JTextField getChooseName() {
        return chooseName;
    }


    /**
     * @return the chooseEmail
     */
    public JTextField getChooseEmail() {
        return chooseEmail;
    }

    /**
     * @return the chooseExpertise
     */
    public JTextField getChooseExpertise() {
        return chooseExpertise;
    }
    
    /**
     * @return the chooseExpertise
     */
    public JTextField getSearchName() {
        return searchName;
    }
    
  private JPanel makePanelOne (String name) {
    // set up the three controls to display
    buttonProf = new JButton ("PROFESSOR");
    buttonLecturer = new JButton ("LECTURER");
    buttonResearcher = new JButton ("RESEARCHER");
    buttonStudent = new JButton ("STUDENT");
    buttonVisitor = new JButton ("VISITOR");
    
    //buttonProf.setPreferredSize(new Dimension(300, 100));
    
    // create the display and place the controls
    JPanel panel = new JPanel ();
    panel.setLayout (new GridLayout (9, 1));
    panel.setBorder (new TitledBorder ("" + name));
    panel.add (new Label("Choose one of the followings: "));
    panel.add (buttonProf);
    panel.add (buttonLecturer);
    panel.add (buttonResearcher);
    panel.add (buttonStudent);
    panel.add (buttonVisitor);

    return panel;
  }
  
  private JPanel makePanelTwo (String name) {
    // set up the three controls to display
    chooseID = new JTextField (20);
    resultID = new JTextPane ();
    buttonID = new JButton ("ENTER ID");
    JScrollPane resultIDScrollable = new JScrollPane(resultID);
   
    
    chooseName = new JTextField ("");
    chooseEmail = new JTextField ("");
    //JLabel resultID = new JLabel ("");
    buttonVisitorInfo = new JButton ("ENTER");
   // buttonVisitorInfo.addActionListener (new ClickListener ());  // <1>
   
   
   JPanel panel = new JPanel();
   panel.setLayout (new GridLayout (2, 1));
   panel.setBorder (new TitledBorder ("" + name));
    // create the display and place the controls
        idPanel = new JPanel ();
        //idPanel.setLayout (new GridLayout (5, 1));
        idPanel.setLayout (new BorderLayout ());
       
        
        JPanel topIdPanel = new JPanel();
         topIdPanel.setLayout (new BorderLayout ());
         
         
        //idPanel.add (new Label("If you are a member of Mont Royal University,")); 
        topIdPanel.add (new Label("ID:"), BorderLayout.WEST);        
        topIdPanel.add (chooseID);
        topIdPanel.add (buttonID, BorderLayout.EAST); 
        
        idPanel.add (topIdPanel,BorderLayout.NORTH); 
        
        idPanel.add(resultID, BorderLayout.CENTER); 
        
        panel.add(idPanel);
        
    visitorInfoPanel = new JPanel ();
    visitorInfoPanel.setLayout(new GridLayout (6, 1));
    visitorInfoPanel.add (new Label("If you are a visitor,")); 
    visitorInfoPanel.add (new Label("Enter your name:"));    
    visitorInfoPanel.add (chooseName);
    visitorInfoPanel.add (new Label("email:"));    
    visitorInfoPanel.add (chooseEmail);
    visitorInfoPanel.add (getButtonVisitorInfo());

    panel.add(visitorInfoPanel);
    
    return panel;
  } // makePanel
  
  private JPanel makePanelThree (String name) {
    // set up the three controls to display
    chooseExpertise = new JTextField ("");
    buttonExpertise = new JButton ("SEARCH BY EXPERTISE");
    resultSearchExpertise = new JTextPane();
    searchName = new JTextField("");
    buttonSearchName = new JButton("SEARCH BY NAME");
    resultSearchName = new JTextPane();
    
    
    // create the display and place the controls
    JPanel panel = new JPanel ();
    panel.setLayout (new GridLayout (9, 3));
    panel.setBorder (new TitledBorder ("" + name));
    panel.add (new Label("Expertise: "));
    panel.add (chooseExpertise);
    panel.add (buttonExpertise);
    panel.add(resultSearchExpertise);
    panel.add (new Label("Name: "));
    panel.add (searchName);
    panel.add (buttonSearchName);
    panel.add(resultSearchName);
    //panel.add(chooseClass);
    //panel.add(buttonSignUp);

    return panel;
  } // makePanelThree
  
   private JPanel makePanelFour (String name) {          
    // set up the three controls to display
    classAppointmentList = new JLabel("Classes: ");
    resultExpertiseFour = new JTextPane ();
      
    JScrollPane jsp = new JScrollPane(resultExpertiseFour);
  
    // create the display and place the controls
    JPanel panel = new JPanel ();
    panel.setLayout (new BorderLayout ());
    //panel.setLayout (new GridLayout (9, 3));
    panel.setBorder (new TitledBorder ("" + name));
    panel.add (classAppointmentList, BorderLayout.NORTH);
    
    panel.add (jsp, BorderLayout.CENTER);
    //panel.add(chooseClass, BorderLayout.WEST);
    //panel.add(buttonSignUp, BorderLayout.SOUTH);
    
    JPanel innerPanel = new JPanel();
    chooseClass = new JTextField("");
    buttonSignUp = new JButton ("CHECK OUT");
    resultSignUp = new JTextPane();
    classAppointment = new JLabel("Class code to sign up:");
    innerPanel.setLayout (new BorderLayout ());
    innerPanel.add(classAppointment, BorderLayout.NORTH);
    //innerPanel.add(new Label("Enter Class Code"), BorderLayout.NORTH);
    innerPanel.add(chooseClass, BorderLayout.CENTER);
    innerPanel.add(buttonSignUp, BorderLayout.EAST);
    innerPanel.add(resultSignUp, BorderLayout.SOUTH);
    
    panel.add(innerPanel, BorderLayout.SOUTH);
    
    
    
    return panel;
  } // makePanelFour
   
   private JPanel makePanelFive (String name) {          
    
    JPanel exitPanel = new JPanel();
    exitPanel.setLayout (new GridLayout (2, 1));
    // create the display and place the controls
    JPanel resultPanel = new JPanel ();
    resultPanel.setLayout (new BorderLayout ());
    //panel.setLayout (new GridLayout (9, 3));
    //resultPanel.setBorder (new TitledBorder ("" + name));
    
    exitPanel.add(resultPanel);
    
    JPanel secondPanel = new JPanel ();
    secondPanel.setLayout (new BorderLayout ());
    
    
    
    buttonExit = new JButton("EXIT");
    //goodByeLabel = new JLabel();
    secondPanel.add( buttonExit, BorderLayout.NORTH);
    //secondPanel.add( goodByeLabel, BorderLayout.CENTER);
    exitPanel.add(secondPanel);
    
    return exitPanel;
  } // makePanelFour
   
   
   public void addController(Controller controller){
		//System.out.println("View      : adding controller");
                buttonProf.addActionListener(controller.getUserInputListener(null, null, null, null));	//need instance of controller before can add it as a listener 
                buttonLecturer.addActionListener(controller.getUserInputListener(null, null, null, null));
                buttonResearcher.addActionListener(controller.getUserInputListener(null, null, null, null));
                buttonStudent.addActionListener(controller.getUserInputListener(null, null, null, null));
                buttonVisitor.addActionListener(controller.getUserInputListener(null, null, null, null));
                buttonID.addActionListener(controller.getUserInputListener(chooseID, null, resultID, null));
                getButtonVisitorInfo().addActionListener(controller.getUserInputListener(chooseName, chooseEmail, null, null));
                buttonExpertise.addActionListener(controller.getUserInputListener(chooseExpertise, null, resultSearchExpertise, resultExpertiseFour));
                buttonSearchName.addActionListener(controller.getUserInputListener(searchName, null, null, resultExpertiseFour));
                buttonSignUp.addActionListener(controller.getUserInputListener(chooseClass, null, null, resultSignUp));
                buttonExit.addActionListener(controller.getUserInputListener(null, null, null, null));
              
    } //addController()
  

    /*
     * method added for implementing Observer
  */
  // Called from the Model
    @Override
    public void update(Observable o, Object obj) {
       //System.out.println("Update in View: " + obj.toString());
     
       resultExpertiseFour.setText(obj.toString());
      
    
    } //Update
    
   
} // View





