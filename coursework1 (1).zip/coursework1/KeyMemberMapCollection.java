/*
 * Generics Class to create a map for keys (name or id) and value (Professor, Lecturer, Researcher, or Student) 
 */
package coursework1;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.TreeMap;


public class KeyMemberMapCollection<A, B> {
    private List<A> keys; 
    private List<B> memberList;
     
    
    private Map<A, B> memberMap;
    
    public KeyMemberMapCollection(List<A> keys, List<B> memberList){
        this.keys = keys;
        this.memberList = memberList;
        
        
        memberMap = new TreeMap<A, B>();
        setMemberMap();
    }
    
   
  public void setMemberMap(){
      for(int i = 0; i < keys.size(); i++) {
          memberMap.put(keys.get(i), memberList.get(i));
      }  
  }
  
  public Map<A, B> getMemberMap(){
      return memberMap;
  }
    
}
