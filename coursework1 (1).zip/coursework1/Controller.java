
package coursework1;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.math.BigInteger;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.JButton;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JScrollPane;
import javax.swing.JTextField;
import javax.swing.JTextPane;
import javax.swing.SwingWorker;
import javax.swing.text.BadLocationException;
import javax.swing.text.Document;

/*
 * 
 * Controller a listener for View and Model
 * 
 */
class Controller{

	//Controller has Model and View hardwired in
	Model model;
	View view;
        
        String buttonText;
        UserInputListener userInputListener;
      
        Controller() {	
		//System.out.println ("Controller()");
        } //Controller()
        
        public UserInputListener getUserInputListener(JTextField chooseTextA, JTextField chooseTextB, JTextPane resultThree, JTextPane resultFour){
            userInputListener = new UserInputListener(chooseTextA, chooseTextB, resultThree, resultFour);
            return userInputListener;
            
        }
  
	public void addModel(Model m){
		//System.out.println("Controller: adding model");
		this.model = m;
        } 

	public void addView(View v){
		//System.out.println("Controller: adding view");
		this.view = v;
	} 
        
   class UserInputListener implements ActionListener {
        private final JTextField chooseTextA;
        private final JTextField chooseTextB;
        private final JTextPane resultThree;
        private final JTextPane resultFour;
       
       public UserInputListener (JTextField chooseTextA, JTextField chooseTextB, JTextPane resultThree, JTextPane resultFour) {
           this.chooseTextA = chooseTextA;
           this.chooseTextB = chooseTextB;
           this.resultThree = resultThree;
           this.resultFour = resultFour;
    }

    public void actionPerformed (ActionEvent e) {                   
    try {
            String buttonText = ((JButton)e.getSource()).getText(); 
            //System.out.println("** 1 *** " + buttonText);
            ComputeWorker worker ;
            if(buttonText.equalsIgnoreCase("PROFESSOR") || buttonText.equalsIgnoreCase("LECTURER") || buttonText.equalsIgnoreCase("RESEARCHER") ||
                    buttonText.equalsIgnoreCase("STUDENT")) {
                view.getStepTwo().setVisible(true);
                view.getStepOne().setVisible(false);
                view.getStepFive().setVisible(true);
                view.getVisitorInfoPanel().setVisible(false);
                view.getIdPanel().setVisible(true);
                worker = new ComputeWorker ("STEP 1", buttonText, null, null, null);
                worker.execute();
            }
                
            if(buttonText.equalsIgnoreCase("VISITOR")) {
                view.getStepTwo().setVisible(true);
                view.getStepOne().setVisible(false);
                view.getStepFive().setVisible(true); 
                view.getIdPanel().setVisible(false);
                view.getVisitorInfoPanel().setVisible(true);

                
                worker = new ComputeWorker ("STEP 1", buttonText, null, null, null);
                worker.execute();
            }
            
            if(buttonText.equalsIgnoreCase("ENTER ID")) {
                if(model.getUserType().equalsIgnoreCase("Researcher") || model.getUserType().equalsIgnoreCase("Student"))
                    view.getStepThree().setVisible(true);
                view.getStepFive().setVisible(true);
                
                String idText = chooseTextA.getText();
                view.getChooseID().setText("");
                
                worker = new ComputeWorker ("STEP 2", idText, null, resultThree, null);
                resultThree.setText ("Working ... please wait");
                resultThree.setText ("Wrong input");
                worker.execute();
            }
            
            if(buttonText.equalsIgnoreCase("ENTER")) {
                view.getStepThree().setVisible(true);
                view.getStepFive().setVisible(true);
                
                String visitorNameText = chooseTextA.getText();
                String visitorEmailText = chooseTextB.getText();
                view.getChooseName().setText("");
                view.getChooseEmail().setText("");
                 
                worker = new ComputeWorker ("STEP 22", visitorNameText, visitorEmailText , null, null);
                worker.execute(); 
            }
             
            if(buttonText.equalsIgnoreCase("SEARCH BY EXPERTISE")) {
                view.getStepFour().setVisible(true);
                view.getStepFive().setVisible(true);
                String expertiseText = chooseTextA.getText();
                view.getChooseExpertise().setText("");
                view.getResultSearchExpertise().setText("");
                worker = new ComputeWorker ("STEP 3", expertiseText, null, resultThree, resultFour);
                resultFour.setText ("Working ... please wait");
                resultFour.setText ("Wrong input");
                worker.execute(); 
            }
            
            if(buttonText.equalsIgnoreCase("SEARCH BY NAME")) {
                view.getStepFour().setVisible(true);
                view.getStepFive().setVisible(true);
                String nameText = chooseTextA.getText();
                view.getSearchName().setText("");
                view.getResultSearchExpertise().setText("");
                
                worker = new ComputeWorker ("STEP 32", nameText, null, resultThree, resultFour);
                resultFour.setText ("Working ... please wait");
                resultFour.setText ("Wrong input");
                worker.execute(); 
            }
            
            if(buttonText.equalsIgnoreCase("CHECK OUT")) {
                String classText = chooseTextA.getText();
               
                view.getChooseClass().setText("");
               
                worker = new ComputeWorker ("STEP 4", classText, null, resultThree, resultFour);
                resultFour.setText ("Working ... please wait");
                resultFour.setText ("Wrong input");
                worker.execute(); 
            }
            
            if(buttonText.equalsIgnoreCase("EXIT")) {
                view.getStepOne().setVisible(true);
                view.getStepTwo().setVisible(false);
                view.getStepThree().setVisible(false);
                view.getStepFour().setVisible(false);
                view.getStepFive().setVisible(false);
              
                view.getResultID().setText("");
                view.getResultSignUp().setText("");
                
                worker = new ComputeWorker ("STEP 5", null, null, null, null);
                //view.getGoodByeLabel().setText ("Goodbye ... ");
                worker.execute();
            }
        } catch (NumberFormatException ex) {
           
            }
        }
   }   
  
  
class ComputeWorker extends SwingWorker<Void, Void> {           
    String textToComputeA;
    String step;
    JTextPane resultTextPaneA;
    String textToComputeB;
    JScrollPane jsp; 
    boolean canSignUp;
    JTextPane resultTextPaneB;
    boolean canBookAppointment;
   
    public ComputeWorker (String step, String textToComputeA, String textToComputeB, JTextPane resultTextPaneA, JTextPane resultTextPaneB) {
        this.textToComputeA = textToComputeA;
        this.step = step;
        this.resultTextPaneA = resultTextPaneA;
        this.textToComputeB = textToComputeB;
        this.resultTextPaneB = resultTextPaneB;
    }

    public Void doInBackground () {                               
      if(step.equalsIgnoreCase("STEP 1"))
        model.setUserType(textToComputeA);
      if(step.equalsIgnoreCase("STEP 2"))
        model.getUserInformationWithUserID(textToComputeA);
      if(step.equalsIgnoreCase("STEP 22"))
        model.setLogInVisitor(textToComputeA, textToComputeB);
      if(step.equalsIgnoreCase("STEP 3"))
        model.getTeachingMemberByExpertise(textToComputeA);
       if(step.equalsIgnoreCase("STEP 32"))
        model.getTeachingMemberByName(textToComputeA);
      if(step.equalsIgnoreCase("STEP 4")) {
          if(model.getUserType().equalsIgnoreCase("Student")){
                canSignUp = model.getSignUp(textToComputeA);
                System.out.println("In Controller, userType AAA: " + model.getUserType());
          }
          if(model.getUserType().equalsIgnoreCase("Visitor") || model.getUserType().equalsIgnoreCase("Researcher")){
                System.out.println("In Controller, userType: " + model.getUserType());
                System.out.println("In Controller, if statement for Step 4: " + model.getAppointmentTaker());
                
                canBookAppointment = model.bookAppointment(model.getAppointmentTaker(), textToComputeA); //textToComputeA is appointment
                
          }
      }
   
      return null;
    }
    
    public void done () { 
      if(step.equalsIgnoreCase("STEP 2")) {
          UniversityMember foundMember = model.getMemberIDMapFactory().get(textToComputeA);
          String appointmentsBooked = "";
          String offerredRegistered = "Classes ";
          if(!foundMember.getType().equalsIgnoreCase("Student")){
              appointmentsBooked = "Appointment booked: \n";
              StaffMember staff = (StaffMember) foundMember;
              appointmentsBooked += staff.getStaffProperty().getAppointmentsBookedString();
              
               offerredRegistered += "offered:";   
               
               if(foundMember.getType().equalsIgnoreCase("Professor") || foundMember.getType().equalsIgnoreCase("Researcher")) {
                   
               }
          }
          else
              offerredRegistered += "registered:";  
        resultTextPaneA.setText (foundMember.getMemberInfoString()+"\n"+ foundMember.getEmail()+"\n"+offerredRegistered+foundMember.getClassListString()
                                 + appointmentsBooked); 

      }
     
      if(step.equalsIgnoreCase("STEP 3")) {
        Document docA = resultTextPaneA.getDocument(); // For Panel 3 textPane to display names only
        Document doc = resultTextPaneB.getDocument();                    
       
          try {
              docA.remove(0, docA.getLength()); // clears text in text pane in Panel 3
              doc.remove(0, doc.getLength()); // clears text in text pane in Panel 4
          } catch (BadLocationException ex) {
              Logger.getLogger(Controller.class.getName()).log(Level.SEVERE, null, ex);
          }
                List<UniversityMember> staffs = model.getTeachingMemberByExpertise(textToComputeA);
                for(UniversityMember s : staffs){
                    try { 
                        // if login person is student, show Classes in Panel 4
                         if(model.getUserType().equalsIgnoreCase("Student")){
                                docA.insertString(docA.getLength (), "\n  - " + s.getLastName() + " , " + s.getFirstName() + " (" + s.getType() + ")" , null);
                                doc.insertString(doc.getLength (), "\n  - " + getTeachingMemberClassInfo(s) , null);
                         }
                        
                         // if login person is visitor, show appointments in Panel 4
                         if(model.getUserType().equalsIgnoreCase("Visitor") || model.getUserType().equalsIgnoreCase("Researcher")) {
                             view.getClassAppointmentList().setText("Appointments available: ");
                             docA.insertString(docA.getLength (), "\n  - " + s.getLastName() + " , " + s.getFirstName() + " (" + s.getType() + ")" , null);
                             view.getClassAppointment().setText("Appointment to book:");
                         }
                             
                        
                    } catch (BadLocationException ex) {
                        Logger.getLogger(Controller.class.getName()).log(Level.SEVERE, null, ex);
                    }
                }
      } 
      
      if(step.equalsIgnoreCase("STEP 32")) {
        Document doc = resultTextPaneB.getDocument();                    
       
          try {
              doc.remove(0, doc.getLength()); // clears text in text pane
          } catch (BadLocationException ex) {
              Logger.getLogger(Controller.class.getName()).log(Level.SEVERE, null, ex);
          } 
                UniversityMember staff = model.getTeachingMemberByName(textToComputeA);
                model.setAppointmentTaker((StaffMember)staff);
                try { 
                         if(model.getUserType().equalsIgnoreCase("Student"))
                                doc.insertString(doc.getLength (), "\n  - " + getTeachingMemberClassInfo(staff) , null);
                         
                         if(model.getUserType().equalsIgnoreCase("Visitor") || model.getUserType().equalsIgnoreCase("Researcher")) {
                             view.getClassAppointmentList().setText("Appointments available: ");
                             doc.insertString(doc.getLength (), "\n  - " + getTeachingMemberAppointmentsInfo(staff) , null);
                             view.getClassAppointment().setText("Appointment to book:");
                         }
                    } catch (BadLocationException ex) {
                        Logger.getLogger(Controller.class.getName()).log(Level.SEVERE, null, ex);
                    }
                
      } 
      
      if(step.equalsIgnoreCase("STEP 4")) {
          if(model.getUserType().equalsIgnoreCase("Student")){
            if(canSignUp)
                resultTextPaneB.setText("You have successfully signed up for class " + textToComputeA);
            if(!canSignUp)
                resultTextPaneB.setText("You can't sign up for class " + textToComputeA);
          }
          
          ////if(model.getUserType().equalsIgnoreCase("Researcher") || model.getUserType().equalsIgnoreCase("Visitor")){
            if(canBookAppointment)
                resultTextPaneB.setText("You have successfully booked for an appointment @ " + textToComputeA);
           /* if(!canBookAppointment)
               resultTextPaneB.setText("You can't book for an appointment @ " + textToComputeA); */
          //}
      }
    }
    
    /*
     * Helper method to print out Class information for students to sign up
    */
    String getTeachingMemberClassInfo(UniversityMember member){
        String memberClassInfo = "";
       if(!member.getType().equalsIgnoreCase("Researcher")) {
            
            memberClassInfo = member.getLastName() + " , " + member.getFirstName() + " (" + member.getType() + ")";
            

            for(MyClasses c : member.getClassList()) {
                memberClassInfo += "\n" + c.getCode();
                memberClassInfo += "\t" + c.getClassName()+ "\t" + c.getClassSchedule() + "\troom: "+ c.getRoom() + "\nspace available: " + c.getFreeSpace()+ "\n" ;
            }
        }
        return memberClassInfo;
    }
    
    /*
     * Helper method to print out appointments for visitor and researcher to sign up
    */
    String getTeachingMemberAppointmentsInfo(UniversityMember member){
        String memberAppointmentInfo = "";
        if(!member.getType().equalsIgnoreCase("Student")) { //Student doesn't have StaffProperty or appointments
            
            //*** staff store the reference to the staff member
            StaffMember staff = (StaffMember) member;
            //appointmentTaker = staff; //This is required to send the staff member who takes appointment to the model 
            StaffProperty property = staff.getStaffProperty();
            
            memberAppointmentInfo = member.getLastName() + " , " + member.getFirstName() + " (" + member.getType() + ")" + "\nAvailable appoinments:";


            for(String appointment : property.getAvailableAppointments()) {
                memberAppointmentInfo += "\n" + appointment;
                //memberClassInfo += "\t" + c.getClassName()+ "\t" + c.getClassSchedule() + "\n";
            }
        }
        return  memberAppointmentInfo;
    }

    }
} //Controller

