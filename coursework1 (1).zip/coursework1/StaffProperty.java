/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package coursework1;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.GregorianCalendar;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author minmm
 */
public class StaffProperty {

    
    private String office;
    private List<String> expertiseList;
    private int appointmentHour;
    //private UniversityMember staffInfo;
    private List<String> availableAppointments;
    //private List<String> bookedAppointments;
    private List<String> juneAppointmentsBooked;
    private List<String> juneAppointmentsMakers;
    private List<String> julyAppointmentsBooked;
    private List<String> julyAppointmentsMakers;
    private List<String> augAppointmentsBooked;
    private List<String> augAppointmentsMakers;
    
    public StaffProperty (String office, List<String> expertiseList, int appointmentHour) {
        this.office = office;
        this.expertiseList = expertiseList;
        this.appointmentHour = appointmentHour;
        this.availableAppointments = new ArrayList<>();
        
        //this.bookedAppointments = new ArrayList<>();
        this.juneAppointmentsBooked = new ArrayList<>();
        this.juneAppointmentsMakers = new ArrayList<>();
        this.julyAppointmentsBooked = new ArrayList<>();
        this.julyAppointmentsMakers = new ArrayList<>();
        this.augAppointmentsBooked = new ArrayList<>();
        this.augAppointmentsMakers = new ArrayList<>();
        //this.staffInfo = new UniversityMember(id, fullName, address, email);
        
        setAvailableAppointments();
        //printAppointments();
    }
     
    
    /**
     * @return the office
     */
    public String getOffice() {
        return office;
    }


    /**
     * @return the expertiseList
     */
    public List<String> getExpertiseList() {
        return expertiseList;
    }

    private void setAvailableAppointments() {
        int date = 1;
        int hh = appointmentHour;
        int mm = 00;
        SimpleDateFormat sdf = new SimpleDateFormat("yyyy MMM dd HH:mm");
        Calendar calendar = new GregorianCalendar(2018, 5, date, hh, mm);
        String appointment;
        
        int daysInMonth; // = calendar.getActualMaximum(Calendar.DAY_OF_MONTH);
        //System.out.println("number of days: " + daysInMonth);
        
        if(appointmentHour == 8 || appointmentHour== 9 || appointmentHour== 10 || appointmentHour== 11 || appointmentHour== 3){
            for(int i = 5; i < 8; i++) {
                calendar.set(Calendar.MONTH, i);
                daysInMonth = calendar.getActualMaximum(Calendar.DAY_OF_MONTH);
                //System.out.println("number of days: " + daysInMonth);
                for(int j = 0; j < daysInMonth ; j++ ) {     
                    // Get the number of days in that month

                   //update a date
                    calendar.set(Calendar.DATE, date + j); 
                    //calendar.set(Calendar.MINUTE, mm); 

                    appointment = sdf.format(calendar.getTime());
                   if (!(calendar.get(Calendar.DAY_OF_WEEK) == Calendar.SATURDAY || calendar.get(Calendar.DAY_OF_WEEK) == Calendar.SUNDAY))
                        availableAppointments.add(appointment);

                }
            }
        }
    }
    
    /*
     * return all available appointments
     */
    public List<String> getAvailableAppointments(){
        return availableAppointments;
    }
    
    /*
     * remove the String appointment from availableAppointments
     */
    public boolean updateAvailableAppointments(String appointment){
        return availableAppointments.remove(appointment);
    }
    
    /*
     * This is written for the report
     */
    public void addMonthlyAppointmentsBooked(String appointmentDateInString, String person){
        try {
            SimpleDateFormat sdf = new SimpleDateFormat("yyyy MMM dd HH:mm");
            Date date = sdf.parse(appointmentDateInString);
            //System.out.println(date.getMonth());
            if(date.getMonth() == 5) {
                juneAppointmentsBooked.add(appointmentDateInString);
                juneAppointmentsMakers.add(person);
                //System.out.println("addMonthlyAppointmentsBooked: June");
            }
             if(date.getMonth() == 6) {
                julyAppointmentsBooked.add(appointmentDateInString);
                julyAppointmentsMakers.add(person);
                //System.out.println("addMonthlyAppointmentsBooked: July");
             }
              if(date.getMonth() == 7) {
                augAppointmentsBooked.add(appointmentDateInString);
                augAppointmentsMakers.add(person);
                //System.out.println("addMonthlyAppointmentsBooked: Aug");
             }    
            
        } catch (ParseException ex) {
            //Logger.getLogger(StaffProperty.class.getName()).log(Level.SEVERE, null, ex);
             System.err.println("Caught ParseException: " + ex.getMessage());
        }
    }
    
    public List<String> getJuneAppointmentsBooked(){
        return juneAppointmentsBooked;
    }
    
    public List<String> getJuneAppointmentsMakers(){
        return juneAppointmentsMakers;
    }
    
    public List<String> getJulyAppointmentsBooked(){
        return julyAppointmentsBooked;
    }
    
    public List<String> getJulyAppointmentsMakers(){
        return julyAppointmentsMakers;
    }
     
    public List<String> getAugAppointmentsBooked(){
        return augAppointmentsBooked;
    }
    
    public List<String> getAugAppointmentsMakers(){
        return augAppointmentsMakers;
    }
    
     public String getAppointmentsBookedString(){
        String appointmentsBookedString = "";
        if(juneAppointmentsBooked != null) {
            for(int i = 0; i <  juneAppointmentsBooked.size() ; i++){
                appointmentsBookedString += juneAppointmentsBooked.get(i)+ " (" + juneAppointmentsMakers.get(i) + ") \n";
                //System.out.println("In StaffProperty: getAppointmentsBookedString adding June to String");
            }
        }
        
        if(julyAppointmentsBooked != null) {
            for(int i = 0; i <  julyAppointmentsBooked.size() ; i++){
                appointmentsBookedString += julyAppointmentsBooked.get(i) + " (" + julyAppointmentsMakers.get(i) + ") \n";
                //System.out.println("In StaffProperty: getAppointmentsBookedString adding July to String");
            }
        }
         
        if(augAppointmentsBooked != null) {
            for(int i = 0; i <  augAppointmentsBooked.size() ; i++){
                appointmentsBookedString += augAppointmentsBooked.get(i) + " (" + augAppointmentsMakers.get(i) + ") \n";
                //System.out.println("In StaffProperty: getAppointmentsBookedString adding Aug to String");
            }
        }
        //System.out.println("In StaffProperty: getAppointmentsBookedString: " + appointmentsBookedString);
        return appointmentsBookedString;
    }
    
    void printAppointments(){
        for(String e : availableAppointments) {
             System.out.println(e);
        }
    }
    

   
    
}
