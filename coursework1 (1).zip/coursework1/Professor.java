
package coursework1;

import java.util.List;

/*
 * Professor class is a subclass of UniversityMember and it implements StaffMember
 */
public class Professor extends UniversityMember implements StaffMember {

    //private List<MyClasses> classList;
    private StaffProperty staffProperty;
    private List<String> expertiseList;
    //private UniversityMember profMemberInfo;
    
    public Professor(String [] uniMemAttrs, StaffProperty staffProperty, List<MyClasses> classList) {
        super(uniMemAttrs, classList);
        //this.profMemberInfo = new UniversityMember(id, fullName, address, email);
        //this.expertiseList = expertiseList;
        this.staffProperty= staffProperty;
       /* if(classList != null){
            this.setClassList(classList);
        }*/
    }
    
    
    /**
     * @return the classList
     */
    public List<String> getExpertise() {
        return this.expertiseList;
    }
    
    public StaffProperty getStaffProperty(){
        return this.staffProperty;
    }
   
    public void printInfo() {
        System.out.println("Professor info: " + super.getId()+ " " + super.getLastName() + " " + super.getAddress() + " " + super.getEmail());
        System.out.println("Staff Properties: " + staffProperty.getOffice() + " " + staffProperty.getExpertiseList());
        if(super.classList != null)
            System.out.println("Classed offered: " + classList.get(0).getClassName());
    }
    public void login () {
        System.out.println("Professor login: " + super.getId()+ " " + super.getLastName() );
    }

    @Override
    public List<String> getExpertiseList() {
        expertiseList = this.staffProperty.getExpertiseList();
        return expertiseList;
    }
    
    public void printJune(){
        String me = super.id + " " + super.lastName + ", " + super.firstName;
        for(int i = 0; i < this.getStaffProperty().getJuneAppointmentsBooked().size(); i++) {
            me += "\n" + this.getStaffProperty().getJuneAppointmentsBooked().get(i) + " : " + this.getStaffProperty().getJuneAppointmentsMakers().get(i);
        }
        System.out.println(me);
    }
    
    
}