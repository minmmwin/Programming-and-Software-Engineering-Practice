/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package coursework1;

/**
 *
 * Interface for Researcher and Visitor who can make appointments with Professor and Lecturer
 */
interface AppointmentMaker {
    
boolean makeAppointment(StaffMember staff, String appointment);
    
}
