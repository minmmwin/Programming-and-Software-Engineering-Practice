/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package coursework1;

import java.util.List;

/**
 *
 * @author minmm
 */
public class Student extends UniversityMember {
    
    
    public Student (String [] uniMemAttrs, List<MyClasses> classList) {
        super(uniMemAttrs, classList);
        
    }
    
    public void addClassList(MyClasses newClass){
       super.getClassList().add(newClass);
    }
    
    /*
     public void printInfo() {
        System.out.println("Student Info: " + super.getId()+ " " + super.getLastName() + " " + super.getAddress() + " " + super.getEmail());
        
    }*/
    /* 
    public void login () {
        System.out.println("Student login: " + super.getId()+ " " + super.getLastName() );
    }
*/
   
}
