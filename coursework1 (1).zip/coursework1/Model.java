
package coursework1;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Observable;
import java.util.Set;
import java.util.TreeMap;
import javax.swing.JTextField;
import javax.swing.SwingWorker;

/*
 * Model holds a instance of UniversityMemberDatabase 
 * Model is an Observable
 * 
 */
public class Model extends Observable {	
	
        private UniversityMemberDatabase db;
        private String userType;
        private Map<String, UniversityMember> userIDMap;
        private UniversityMember logInMember;
        private Visitor logInVisitor;
        private Set<Visitor> visitorDb;
        private StaffMember appointmentTaker;

	public Model(){

		//System.out.println("Model()");
                db = UniversityMemberDatabase.getInstance();
                visitorDb = new HashSet<>();
	} 


    public void setUserType(String buttonText) {
       userType = buttonText;
       if(!userType.equalsIgnoreCase("Visitor"))
            userIDMap = getMemberIDMapFactory();
    }
    
    public String getUserType(){
        return userType;
    }
    
    public void setAppointmentTaker(StaffMember appointmentTaker){
        this.appointmentTaker = appointmentTaker;
    }
    
    public StaffMember getAppointmentTaker(){
        return appointmentTaker;
    }
    

    /*
     * Factory Method to get the appropiate collection of user depending on click at Step 1
     */
    public Map<String, UniversityMember> getMemberIDMapFactory(){
        Map<String, UniversityMember> userIDMap = new TreeMap<>();
        if(userType.equalsIgnoreCase("PROFESSOR"))
            userIDMap = db.getProfessorIDMap();
        if(userType.equalsIgnoreCase("LECTURER"))
            userIDMap = db.getLecturerIDMap();
        if(userType.equalsIgnoreCase("RESEARCHER"))
            userIDMap = db.getResearcherIDMap();
        if(userType.equalsIgnoreCase("STUDENT"))
            userIDMap = db.getStudentIDMap();
        
        return userIDMap;
        
    }

    public void getUserInformationWithUserID(String idText) {
        System.out.println("UserID sent from View through Controller: " + idText);
        logInMember = userIDMap.get(idText);
    }
    
    public UniversityMember getLogInMember(){
        return logInMember;
    }
    
    public void setLogInVisitor(String visitorName, String visitorEmail) {
        logInVisitor = new Visitor("Visitor", visitorName, visitorEmail);
        visitorDb.add(logInVisitor);
        for(Visitor s : visitorDb){
            System.out.println(s.getFullName());
        }
    }
    
    public Visitor getVisitor(){
        return logInVisitor;
    }
    

    List<UniversityMember> getTeachingMemberByExpertise(String expertiseText) {
        if(db.containsExpertise(expertiseText)) {
                
            return db.getExpertiseMapAllStaffMembers().get(expertiseText);
        }
        return null;
        
    }
    
     public UniversityMember getTeachingMemberByName(String textToComputeA) {
        UniversityMember staffMember;
        if(db.getProfessorNameMap().containsKey(textToComputeA)) {
            staffMember = db.getProfessorNameMap().get(textToComputeA);
            System.out.println("teachingMember: " + staffMember.getId());
            return staffMember;
        }
        
        if(db.getLecturerNameMap().containsKey(textToComputeA)) {
            staffMember = db.getLecturerNameMap().get(textToComputeA);
            System.out.println("teachingMember: " + staffMember.getId());
            return staffMember;
         }
        
        if(db.getResearcherNameMap().containsKey(textToComputeA)) {
            staffMember = db.getResearcherNameMap().get(textToComputeA);
            System.out.println("teachingMember: " + staffMember.getId());
            return staffMember;
         }
         
        return null;
    }

     public boolean getSignUp(String textToComputeA) {
        MyClasses choosenClass = MyClasses.getAllClassesMap().get(textToComputeA);
        System.out.println(choosenClass.getClassName()+ " signed up by " + logInMember.id);
        boolean canSignUp = choosenClass.signUp(logInMember);
        System.out.println("in Model: " + canSignUp);
        return canSignUp;
        
    }

    boolean bookAppointment(StaffMember appointmentTaker, String textToComputeA) {
       
        boolean makeAppointment =  false;
        
        if(userType.equalsIgnoreCase("Researcher")) {
            System.out.println("in Model, Researcher: " + logInMember.getLastName()+ " " + textToComputeA + "AppointmentTaker: " + appointmentTaker);
            Researcher researcher = (Researcher) logInMember; 
            makeAppointment = researcher.makeAppointment(appointmentTaker, textToComputeA);
            System.out.println("makeAppointment: " + makeAppointment);
        }
        
        if(userType.equalsIgnoreCase("Visitor")) {
            Visitor visitor = getVisitor();
        
        
            if(!visitor.equals(null)) {
                System.out.println("in Model, visitor: " + visitor.getFullName() + " " + textToComputeA + "AppointmentTaker: " + appointmentTaker);
                makeAppointment = visitor.makeAppointment(appointmentTaker, textToComputeA);
                System.out.println("makeAppointment: " + makeAppointment);
            }
        }

        
        return makeAppointment;
         
        
    }

   
    
    
	
} //Model