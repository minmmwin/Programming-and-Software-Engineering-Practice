/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package coursework1;

import java.time.LocalTime;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.TreeMap;
import java.util.TreeSet;

/**
 *
 * @author minmm
 */
public class MyClasses {

    public final int MAXCAPACITY = 10;
    private String code;
    private String className;
    private String room;
    //private ArrayList<String> classSchedule;
    private String classSchedule;
    private String classDay;
    private String start;
    private String end;
    //private int totalStudents;
    private Set<UniversityMember> studentSet;
    
    private static Map<String, MyClasses> allClassesMap = new TreeMap<>();
    
    
    //public MyClasses(String className, String room, String classSchedule, int totalStudents) {
    //public MyClasses(String code, String className, String room, String classDay, String start, String end){
     public MyClasses(String [] classInfo){
        if (classInfo.length == 6) {
            try {
                this.code =  classInfo[0];
                this.className =  classInfo[1];
                this.room = classInfo[2];
                this.classDay = classInfo[3];
                this.start = classInfo[4];
                this.end = classInfo[5];
            } catch (NumberFormatException ex) {
            System.out.println ("UGH");
            }
            } else {
            System.out.println(" Wrong number of arguments ");
            } 
     
        this.setClassSchedule(classDay, start, end);
        //this.totalStudents = totalStudents;
        //this.setTotalStudents(totalStudents);
        studentSet = new HashSet<UniversityMember>();
        allClassesMap.put(this.code, this);
        
    }
    
     public void addStudent(UniversityMember student){
        studentSet.add(student);
        //totalStudents++;
    }
    public boolean signUp(UniversityMember s){
        // if student has at least 1 class signed up and new class to sign up is not in the same time 
        //System.out.println("s: " +s.getLastName());
        if(s.getClassList().size() > 0) {
            for(int i = 0; i< s.getClassList().size(); i++) { // for
               if(checkConcurrentClasses(this, s.getClassList().get(i))) { // if
                   return false;
                    
                }
            }
        }
        
        // student can't sign up the same class again
        if(!studentSet.contains(s)){
            
            if(studentSet.size() < MAXCAPACITY){
                Student student = (Student) s;
                student.addClassList(this);
                addStudent(s);
                return true;
            }
            else
                return false;
                //}if
                //return false;
            //} //for    
        }
        return false;
    }
    
    public boolean checkConcurrentClasses(MyClasses classOne, MyClasses classTwo){
        if(classOne.classDay.equalsIgnoreCase(classTwo.classDay)) {
            DateTimeFormatter formatter = DateTimeFormatter.ofPattern("HH:mm");
            String oneStart = classOne.start;
            String oneEnd = classOne.end;
            String twoStart = classTwo.start;
            String twoEnd = classTwo.end;

            LocalTime startA = LocalTime.parse( oneStart, formatter);
            LocalTime endA = LocalTime.parse( oneEnd, formatter);
            LocalTime startB = LocalTime.parse( twoStart, formatter);
            LocalTime endB = LocalTime.parse( twoEnd, formatter);

            Boolean validA = ( ! startA.isAfter( endA ) ) ;
            Boolean validB = ( ! startB.isAfter( endB ) ) ;

            Boolean overlaps = ( ( startA.isBefore( endB ) ) && ( endA.isAfter( startB ) ) ) ;

            //System.out.println("Overlaps: ? " + overlaps);
            
            return overlaps;
        }
        
        else
            return false;
        
    }
    
    /**
     * @return the code
     */
    public String getCode() {
        return code;
    }
    
    /**
     * @return the className
     */
    public String getClassName() {
        return className;
    }

    /**
     * @param className the className to set
     */
    public void setClassName(String className) {
        this.className = className;
    }

    /**
     * @return the room
     */
    public String getRoom() {
        return room;
    }

    /**
     * @param room the room to set
     */
    public void setRoom(String room) {
        this.room = room;
    }

    public String getClassSchedule() {
        return classSchedule;
    }

   
    public void setClassSchedule(String classDay,  String start, String end) {
        this.classSchedule = classDay + " " + start + "-" + end;
    } 
    
    public int getFreeSpace(){
        return MAXCAPACITY - studentSet.size();
    }
 
    /**
     * @return the roomCapacity
     */
    public int getTotalStudents() {
        return studentSet.size();
    }
    
    public static Map<String, MyClasses> getAllClassesMap(){
        return allClassesMap;
    }

    
    
    
}
