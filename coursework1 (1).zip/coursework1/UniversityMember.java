/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package coursework1;

import java.util.Iterator;
import java.util.List;
import static java.util.Spliterators.iterator;

/**
 * Singleton Pattern to create University Member
 * @author minmm
 */
public abstract class UniversityMember {
    protected String type;
    protected String id;
    protected String lastName;
    protected String firstName;
    protected String address;
    protected String email;
    protected List<MyClasses> classList;
    //private static UniversityMember instance = new UniversityMember();
    
    //UniversityMember(String id, String lastName,String firstName, String address, String email, List<MyClasses> classList) {
    //UniversityMember(String id, String fullName){
    UniversityMember(String [] uniMemAttrs, List<MyClasses> classList) {
         if (uniMemAttrs.length == 6) {
            try {
                this.type =  uniMemAttrs[0];
                this.id =  uniMemAttrs[1];
                this.lastName = uniMemAttrs[2];
                this.firstName = uniMemAttrs[3];
                this.address = uniMemAttrs[4];
                this.email = uniMemAttrs[5];
            } catch (NumberFormatException ex) {
            System.out.println ("UGH");
            }
            } else {
            System.out.println(" Wrong number of arguments ");
            }
        
        this. classList = classList;
    }
    
    public String getType() {
        return type;
    }
    
    //abstract void printInfo();
    /**
     * @return the email
     */
    public String getEmail() {
        return email;
    }

    /**
     * @param email the email to set
     */
    public void setEmail(String email) {
        this.email = email;
    }

    /**
     * @return the address
     */
    public String getAddress() {
        return address;
    }

    /**
     * @param address the address to set
     */
    public void setAddress(String address) {
        this.address = address;
    }

    /**
     * @return the fullName
     */
    public String getLastName() {
        return lastName;
    }

    /**
     * @return the fullName
     */
    public String getFirstName() {
        return firstName;
    }


    /**
     * @return the id
     */
    public String getId() {
        return id;
    }

    /**
     * @param id the id to set
     */
    public void setId(String id) {
        this.id = id;
    }
    
    public String getMemberInfoString() {
        String info = lastName+", "+firstName+"\n"+id;
        return info;
    }
    
    public List<MyClasses> getClassList(){
        return this.classList;
    }
    
    public String getClassListString(){
        String classListString = "\n";
        if(classList != null) {
            for(int i = 0; i <  classList.size() ; i++){
                classListString += classList.get(i).getClassName() + "; " + classList.get(i).getClassSchedule() + " room: " + classList.get(i).getRoom() ;
                classListString += "\n";
            }
        }
        return classListString;
    }
    
}
