/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package coursework1;

import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.Iterator;
import java.util.List;

/**
 *
 * @author minmm
 */
public class UniversityMemberCreationThread extends Thread {
   private String message;
   
    List<UniversityMember> professorList = new ArrayList();
        List<UniversityMember> lecturerList = new ArrayList();
        List<UniversityMember> researcherList = new ArrayList();
        List<UniversityMember> studentList = new ArrayList();
   

  public UniversityMemberCreationThread (String message) {
    this.message = message;
  }

  public void run () {                                    
         
        /*
         * Duplicate codes for creating Professors and Lecturers can be refactored with a method createTeachingStaff(....) just as createStudent()
         */
        List<String> profAExpertise = new ArrayList();
        profAExpertise.add("programming");
        profAExpertise.add("data analysis");
        StaffProperty profAStaffProperty = new StaffProperty("A01", profAExpertise, 10);
        List<MyClasses> profAClasses = new ArrayList();
        profAClasses.add(new MyClasses(new String[]{"jvp101", "Java Programming 1", "G01", "Monday", "8:00", "9:00"}));  
        profAClasses.add(new MyClasses(new String[]{"jvp102","Java Programming 2", "G01", "Tuesday", "8:00", "9:00"})); 
        UniversityMember profA = new Professor(new String[]{"Professor", "p101", "smith", "Mike", "Guy St., Montreal, QC, Canada", "mikesmith@unimail.ca"}, profAStaffProperty , profAClasses);
        professorList.add(profA);
        
        List<String> profBExpertise = new ArrayList();
        profBExpertise.add("security");
        StaffProperty profBStaffProperty = new StaffProperty("A02", profBExpertise, 8);
        List<MyClasses> profBClasses = new ArrayList();
        profBClasses.add(new MyClasses(new String[]{"csf101","System Foundation 1", "G02", "Monday", "10:00", "11:00"}));   
        profBClasses.add(new MyClasses(new String[]{"csf102","System Foundation 2", "G02", "Tuesday", "10:00", "11:00"}));   
        UniversityMember profB = new Professor(new String[]{"Professor", "p102", "catalan", "Jody", "Peel St., Montreal, QC, Canada", "jodycatalan@unimail.ca"}, profBStaffProperty , profBClasses);
        professorList.add(profB);
        
        List<String> lecturerAExpertise = new ArrayList();
        lecturerAExpertise.add("mathematics");
        StaffProperty lecturerAStaffProperty = new StaffProperty("B01", lecturerAExpertise, 11);
        List<MyClasses> lecturerAClasses = new ArrayList();
        lecturerAClasses.add(new MyClasses(new String[]{"ecc101","Engineering Calculus 1", "H01", "Monday", "8:00", "9:00"}));
        lecturerAClasses.add(new MyClasses(new String[]{"ecc102","Engineering Calculus 2", "H01", "Wednesday", "8:00", "9:00"}));
        UniversityMember lecturerA = new Lecturer(new String[]{"Lecturer", "l101", "vander", "Alex", "Berri St., Montreal, QC, Canada", "alexvander@unimail.ca"}, lecturerAStaffProperty, lecturerAClasses);
        lecturerList.add(lecturerA);
        
        List<String> lecturerBExpertise = new ArrayList();
        lecturerBExpertise.add("programming");
        StaffProperty lecturerBStaffProperty = new StaffProperty("B02", lecturerBExpertise, 9);
        List<MyClasses> lecturerBClasses = new ArrayList();
        lecturerBClasses.add(new MyClasses(new String[]{"ccp101","c++ Programming", "H02", "Tuesday", "12:00", "1:00"}));
        lecturerBClasses.add(new MyClasses(new String[]{"ptp102","Python Programming", "H02", "Thursday", "12:00", "1:00"}));
        UniversityMember lecturerB = new Lecturer(new String[]{"Lecturer", "l102", "rogers", "Andrew", "Rogers St., Montreal, QC, Canada", "andrewrogers@unimail.ca"}, lecturerBStaffProperty, lecturerBClasses);
        lecturerList.add(lecturerB);
        
        List<String> researcherAExpertise = new ArrayList();
        researcherAExpertise.add("Web Development");
        StaffProperty researcherAStaffProperty = new StaffProperty("C01", researcherAExpertise, 3);
        UniversityMember researcherA = new Researcher(new String[]{"Researcher", "r101", "Corvec", "Shawn", "Bishop St., Montreal, QC, Canada", "shawncorvec@unimail.ca"}, researcherAStaffProperty);
        
        researcherList.add(researcherA);
        
        createStudent("Student", "s101", "Win", "Min", "Bishop St., Montreal, QC, Canada", "minwin@unimail.ca");
        createStudent("Student", "s102", "Storey", "Mike", "2nd St., Montreal, QC, Canada", "storey@unimail.ca");
        createStudent("Student", "s103", "Min", "Aye", "3rd St., Montreal, QC, Canada", "aye@unimail.ca");
        createStudent("Student", "s104", "Bo", "Bo", "4th St., Montreal, QC, Canada", "BoBo@unimail.ca");
        createStudent("Student", "s105", "Game", "Joe", "5th St., Montreal, QC, Canada", "game@unimail.ca");
        createStudent("Student", "s106", "Warren", "Andrew", "6th St., Montreal, QC, Canada", "warren@unimail.ca");
        createStudent("Student", "s107", "Divo", "John", "7th St., Montreal, QC, Canada", "divo@unimail.ca");
        createStudent("Student", "s108", "Strong", "Cathy", "8th St., Montreal, QC, Canada", "strong@unimail.ca");
        createStudent("Student", "s109", "Nicole", "Richard", "9th St., Montreal, QC, Canada", "richard@unimail.ca");
        createStudent("Student", "s110", "Mazhur", "Luke", "10th St., Montreal, QC, Canada", "mazhur@unimail.ca");

      
    /*    List<MyClasses> studentAClasses = new ArrayList();
        UniversityMember studentA = new Student(new String[]{"Student", "s101", "Win", "Min", "Bishop St., Montreal, QC, Canada", "minwin@unimail.ca"}, studentAClasses);
        studentList.add(studentA); */
        
     /*   List<MyClasses> studentBClasses = new ArrayList();
        UniversityMember studentB = new Student(new String[]{"Student", "s102", "Storey", "Michael", "Story St., Montreal, QC, Canada", "ms@unimail.ca"}, studentBClasses);
        studentList.add(studentB);
    */
      
     UniversityMemberDatabase.init(professorList, lecturerList, researcherList, studentList);
     UniversityMemberDatabase db = UniversityMemberDatabase.getInstance();
     
     /*
      * To print the monthly report
      */
        DateFormat dateFormat = new SimpleDateFormat("yyyy/MM/dd HH:mm:ss");
        DateFormat dateFormat1 = new SimpleDateFormat("yyyy/MM/dd");
	Date date = new Date();
	//System.out.println(dateFormat.format(date)); //2016/11/16 12:08:43
        System.out.println(dateFormat1.format(date)); 
        
        //System.out.println(dateFormat1.format(date).equalsIgnoreCase("2018/05/07"));
        
        if(dateFormat1.format(date).equalsIgnoreCase("2018/07/01")){
            System.out.println("Printing the report for June, 2018");
            
        }
        
        if(dateFormat1.format(date).equalsIgnoreCase("2018/08/01")){
            System.out.println("Printing the report for July, 2018");
            
        }
        
        if(dateFormat1.format(date).equalsIgnoreCase("2018/09/01")){
            System.out.println("Printing the report for Aug, 2018");
            
        }
  } 
  
  void createStudent(String type, String id, String last, String first, String add, String email){
        List<MyClasses> studentClasses = new ArrayList();
        UniversityMember student = new Student(new String[]{type, id, last, first, add, email}, studentClasses);
        studentList.add(student);
  }
  
  void createStaffMember(){
      
  }
}
