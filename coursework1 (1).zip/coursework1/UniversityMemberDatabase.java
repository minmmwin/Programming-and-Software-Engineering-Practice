
package coursework1;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Dictionary;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.TreeMap;

/**
 * 
 * 
 */
public class UniversityMemberDatabase {
    private static UniversityMemberDatabase uniqueInstance; // a static variable to hold one instance of the class SingletonLogger
    //private U members;
    private List<String> expertiseListMain;
    
    private List<String> allProfessorExpertises;
    private List<String> allLecturerExpertises;
    private List<String> allResearcherExpertises;
    //private List<String> studentLastNames;
    
    private Map<String, ArrayList<UniversityMember>> expertiseMapAllStaffMembers;
    private List<String> expertiseListAll;
   
    private List<UniversityMember> professorList;
    private List<UniversityMember> lecturerList;
    private List<UniversityMember> researcherList;
    private List<UniversityMember> studentList;
    
    
    private List<String> professorLastNames;
    private List<String> lecturerLastNames;
    private List<String> researcherLastNames ;
    private List<String> studentLastNames;
    
    private List<String> professorIDs;
    private List<String> lecturerIDs;
    private List<String> researcherIDs;
    private List<String> studentIDs;
    
    private Map<String, UniversityMember> professorNameMap;
    private Map<String, UniversityMember> lecturerNameMap;
    private Map<String, UniversityMember> researcherNameMap;
    private Map<String, UniversityMember> studentNameMap;
    
    private Map<String, UniversityMember> professorIDMap;
    private Map<String, UniversityMember> lecturerIDMap;
    private Map<String, UniversityMember> researcherIDMap;
    private Map<String, UniversityMember> studentIDMap;
    
    KeyMemberMapCollection genericsCollection;
   
  private UniversityMemberDatabase (List<UniversityMember> professorList, List<UniversityMember> lecturerList, List<UniversityMember> researcherList, List<UniversityMember> studentList) {
      this.professorList = professorList;
      this.lecturerList = lecturerList;
      this.researcherList = researcherList;
      this.studentList = studentList;
      
      this.allProfessorExpertises = new ArrayList();
      this.allLecturerExpertises = new ArrayList();
      this.allResearcherExpertises = new ArrayList();
      
      this.expertiseMapAllStaffMembers = new HashMap<>();
      this.expertiseListAll = new ArrayList<>();
      
      this.allProfessorExpertises = getMemberExpertises(professorList);
      this.allLecturerExpertises = getMemberExpertises(lecturerList);
      this.allResearcherExpertises = getMemberExpertises(researcherList);
      
      
      this.professorLastNames = new ArrayList();
      this.lecturerLastNames = new ArrayList();
      this.researcherLastNames = new ArrayList();
      this.studentLastNames = new ArrayList();
      
      this.professorNameMap = new TreeMap<>(); 
      this.lecturerNameMap = new TreeMap<>(); 
      this.researcherNameMap = new TreeMap(); 
      this.studentNameMap = new TreeMap<>();
      
      
      this.professorLastNames = getMemberLastNames(professorList);
      this.lecturerLastNames = getMemberLastNames(lecturerList);
      this.researcherLastNames = getMemberLastNames(researcherList);
      this.studentLastNames = getMemberLastNames(studentList);
      
      this.professorIDs = getMemberIDs(professorList);
      this.lecturerIDs = getMemberIDs(lecturerList);
      this.researcherIDs = getMemberIDs(researcherList);
      this.studentIDs = getMemberIDs(studentList);
      
      
      professorNameMap = new KeyMemberMapCollection(professorLastNames, professorList).getMemberMap();
      lecturerNameMap = new KeyMemberMapCollection(lecturerLastNames, lecturerList).getMemberMap();
      researcherNameMap = new KeyMemberMapCollection(researcherLastNames, researcherList).getMemberMap();
      studentNameMap = new KeyMemberMapCollection(studentLastNames, studentList).getMemberMap();
      
      professorIDMap = new KeyMemberMapCollection(professorIDs, professorList).getMemberMap();
      lecturerIDMap = new KeyMemberMapCollection(lecturerIDs, lecturerList).getMemberMap();
      researcherIDMap = new KeyMemberMapCollection(researcherIDs, researcherList).getMemberMap();
      studentIDMap = new KeyMemberMapCollection(studentIDs, studentList).getMemberMap();
      
        // ensure the list is sorted
        //*******************
        Collections.sort(expertiseListAll);
        
        Collections.sort(professorLastNames);
        Collections.sort(lecturerLastNames);
        Collections.sort(studentLastNames);
        Collections.sort(researcherLastNames);
        Collections.sort(professorIDs);
        Collections.sort(lecturerIDs);
        Collections.sort(studentIDs);
        Collections.sort(researcherIDs);
  }
  
  public static UniversityMemberDatabase getInstance () { // method to instantiate the class and return an instance of it
        /* if (uniqueInstance == null) {                // if instance does not exist
           uniqueInstance = new UniversityMemberDatabase (professorList, lecturerList, researcherList, studentList);  // create it - Notice that the level is set here
         }*/
         return uniqueInstance;                       // return the single instance
  }
  
  public static void init(List<UniversityMember> professorList, List<UniversityMember> lecturerList, List<UniversityMember> researcherList, List<UniversityMember> studentList){
        uniqueInstance = new UniversityMemberDatabase(professorList, lecturerList, researcherList, studentList);  // create it - Notice that the level is set here;
 }
  
  public List<UniversityMember> getProfessorList(){
      return this.professorList;
      
  }
  
  public List<UniversityMember> getResearcherList(){
      return this.researcherList;
      
  }
  
   public List<UniversityMember> getStudentList(){
      return this.studentList;
      
  }
   
   /*
    * Can't use UniversityMember here because it doesn't have getExpertise() method, only staff member has expertises
   */
   public List<String> getMemberExpertises(List<UniversityMember> memberList) {
       List<String> expertiseList = new ArrayList();
     for(UniversityMember s : memberList ){
         StaffMember sm = (StaffMember) s;
          for(String e : sm.getExpertiseList()){
               expertiseList.add(e);
               setExpertiseMapWithMember(e, sm);
          }
      }
      return expertiseList;
   } 
   
   /*
    * This function also set expertiseListAll which store a list of all expertise of string type
   */
   public void setExpertiseMapWithMember(String e, StaffMember member){
       UniversityMember me = (UniversityMember) member;
       if(this.expertiseMapAllStaffMembers.containsKey(e)){
           expertiseMapAllStaffMembers.get(e).add(me);
       }
       else {
          ArrayList<UniversityMember> staffList = new ArrayList<>(); 
          staffList.add(me);
            this.expertiseMapAllStaffMembers.put(e, staffList);
            expertiseListAll.add(e);
       }
      //this.expertiseMapAllStaffMembers.containsKey(e);
   }
   
   public Map <String, ArrayList <UniversityMember>> getExpertiseMapAllStaffMembers(){
       return expertiseMapAllStaffMembers;
   }
   
   public List<String> getExpertiseListAll() {
       return expertiseListAll;
   }
   
  //Refactor codes for 4 different members
  public List<String> getMemberLastNames(List<UniversityMember> memberList) {
      List<String> lastNames = new ArrayList();
      for(UniversityMember s : memberList ){
          lastNames.add(s.getLastName());
      }
      return lastNames;
  }
  
  //Refactor codes for 4 different members
  public List<String> getMemberIDs(List<UniversityMember> memberList) {
      List<String> iDs = new ArrayList();
      for(UniversityMember s : memberList ){
          iDs.add(s.getId());
      }
      return iDs;
  }
   
  public List<String> getProfessorLastNames(){     
      return professorLastNames; 
  }
  
 
   public Map<String, UniversityMember> getProfessorNameMap(){
       return professorNameMap;
   }
   
   public Map<String, UniversityMember> getResearcherNameMap(){
       return researcherNameMap;
   }
   
   public Map<String, UniversityMember> getLecturerNameMap(){
       return lecturerNameMap;
   }
   
   public Map<String, UniversityMember> getStudentNameMap(){
       return studentNameMap;
   }
   
   public Map<String, UniversityMember> getProfessorIDMap(){
       return professorIDMap;
   }
   
   public Map<String, UniversityMember> getLecturerIDMap(){
       return lecturerIDMap;
   }
   
   public Map<String, UniversityMember> getResearcherIDMap(){
       return researcherIDMap;
   }
   
   
   public Map<String, UniversityMember> getStudentIDMap(){
       return studentIDMap;
   }
   
 
  
  public List<String> getStudentLastNames(){     
      return studentLastNames;
  }
  
  public List<String> getResearcherLastNames(){     
      return researcherLastNames;
  }
  
  public boolean containsExpertise (String expertise) {
      
    int result = Collections.binarySearch (expertiseListAll, expertise);
    
    return result >= 0;                                                     // <2>
  }

  public boolean containsName (String name) {
      
    int resultP = Collections.binarySearch (professorLastNames, name);
    int resultL = Collections.binarySearch (lecturerLastNames, name);
    int resultR = Collections.binarySearch (researcherLastNames, name);
    
   
    return resultP >= 0 || resultL >= 0 || resultR >= 0;                                                     // <2>
  }
  
   public boolean containsStudentName (String name) {

    int result = Collections.binarySearch (professorLastNames, name);

    return result >= 0;                                                     // <2>
  }

   

  
  
  
}
