/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package coursework1;

import java.util.ArrayList;
import java.util.List;
import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;
import static org.junit.Assert.*;

/**
 *
 * @author minmm
 */
public class MyClassesTest {
    List<MyClasses> profAClasses = new ArrayList();
    UniversityMember profA; 
    UniversityMember profB;
    UniversityMember studentA; 
    MyClasses classA;
    MyClasses classB;
    MyClasses classC;
    MyClasses classD;
    
    List<MyClasses> studentAClasses = new ArrayList();
            
    public MyClassesTest() {
        profAClasses.add(new MyClasses(new String[]{"JVP101","Java Programming 1", "G01", "Monday", "9:00", "11:00"}));  
        profAClasses.add(new MyClasses(new String[]{"JVP102","Java Programming 2", "G02", "Tuesday", "9:00", "11:00"}));  
        profA = new Professor(new String[]{"Professor", "P101", "Smith", "Mike", "Guy St., Montreal, QC, Canada", "mikesmith@unimail.ca"}, null , profAClasses);
        studentA = new Student(new String[]{"Student", "S401", "Win", "Min", "Bishop St., Montreal, QC, Canada", "minwin@unimail.ca"}, studentAClasses);
        
        classA = new MyClasses(new String[]{"JVP101","Java Programming 1", "G01", "Monday", "09:00", "11:00"});
        classB = new MyClasses(new String[]{"CDP101","C++ Programming", "G01", "Monday", "10:00", "12:00"});
        classC = new MyClasses(new String[]{"DTB101","Database", "G01", "Tuesday", "09:00", "11:00"});
        classD = new MyClasses(new String[]{"SYA101","System Architecture", "G01", "Tuesday", "12:00", "14:00"});
    
    }
    
    
    /**
     * Test of signUp method, of class ClassOffered.
     */
    @Test
    public void testSignUp() {
        
        assertEquals(true, classA.signUp(studentA));
        //studentA.getClassList().add(classA);
        
        assertEquals(false, classA.signUp(studentA)); // student can't sign up the same class 
        assertEquals(false, classB.signUp(studentA)); // can't sign up the class that overlaps
        assertEquals(true, classC.signUp(studentA)); // OK
        //studentA.getClassList().add(classC);
        assertEquals(true, classD.signUp(studentA)); // OK
        //studentA.getClassList().add(classD);
        assertEquals(3, studentA.getClassList().size()); 
        
    }

    /**
     * Test of addStudent method, of class ClassOffered.
     */
    @Test
    public void testAddStudent() {
         profA.getClassList().get(0).addStudent(studentA);
         assertEquals(1, profA.getClassList().get(0).getTotalStudents());
    }

    @Test
    public void testCheckConcurrentClasses() {
        assertEquals(true, classA.checkConcurrentClasses(classA, classB));
        assertEquals(false, classA.checkConcurrentClasses(classA, classC));
        assertEquals(false, classB.checkConcurrentClasses(classB, classC));
        assertEquals(false, classC.checkConcurrentClasses(classC, classD));
        
    }
    /**
     * Test of getClassName method, of class ClassOffered.
     */
    @Test
    public void testGetClassName() {
        assertEquals("Java Programming 1", profA.getClassList().get(0).getClassName());
        assertEquals("Java Programming 2", profA.getClassList().get(1).getClassName());
        
    }

   

    /**
     * Test of getRoom method, of class ClassOffered.
     */
    @Test
    public void testGetRoom() {
        assertEquals("G01", profA.getClassList().get(0).getRoom());
        assertEquals("G02", profA.getClassList().get(1).getRoom());
    }

    /**
     * Test of getClassSchedule method, of class ClassOffered.
     */
    @Test
    public void testGetClassSchedule() {
        assertEquals("Monday 9:00-11:00", profA.getClassList().get(0).getClassSchedule());
        assertEquals("Tuesday 9:00-11:00", profA.getClassList().get(1).getClassSchedule());
    }

    
    @Test
    public void testGetAllClassesMap() {
        assertEquals(5, MyClasses.getAllClassesMap().size());
        assertEquals("Java Programming 1", MyClasses.getAllClassesMap().get("JVP101").getClassName());
        assertEquals("Monday 09:00-11:00", MyClasses.getAllClassesMap().get("JVP101").getClassSchedule());
        assertEquals("C++ Programming", MyClasses.getAllClassesMap().get("CDP101").getClassName());
        assertEquals("G01", MyClasses.getAllClassesMap().get("CDP101").getRoom());
    }
    
}
