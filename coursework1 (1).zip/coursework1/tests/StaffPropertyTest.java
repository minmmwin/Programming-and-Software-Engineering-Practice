/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package coursework1;

import java.util.ArrayList;
import java.util.List;
import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;
import static org.junit.Assert.*;

/**
 *
 * @author minmm
 */
public class StaffPropertyTest {
    List<String> expertiseList;
    StaffProperty staffProperty;
    List<String> availableAppointments;
    
    public StaffPropertyTest() {
        expertiseList = new ArrayList();
        expertiseList.add("Programming");
        staffProperty = new StaffProperty("A01", expertiseList, 9 );
        availableAppointments = staffProperty.getAvailableAppointments();
    }

    /**
     * Test of getOffice method, of class StaffProperty.
     */
    @Test
    public void testGetOffice() {
        assertEquals("A01", staffProperty.getOffice());
    }

    /**
     * Test of getExpertiseList method, of class StaffProperty.
     */
    @Test
    public void testGetExpertiseList() {
        assertEquals("Programming", staffProperty.getExpertiseList().get(0));
    }
    
    public void testGetAvailableAppointments(){
        assertEquals(66,staffProperty.getAvailableAppointments().size());
        assertEquals("2018 Jun 01 09:00", staffProperty.getAvailableAppointments().get(0));
        assertEquals("2018 Jul 16 09:00", staffProperty.getAvailableAppointments().get(31));
        assertEquals("2018 Aug 31 09:00", staffProperty.getAvailableAppointments().get(65)); 
    }
    /*
     * Test total weekdays for 120 days starting June 1st to Aug 31st 2018 
     * Test first weekday, middle weekday and last weekday of June, Jul and Aug
     */
    
    @Test
    public void testSetAvailableAppointments(){
       //assertEquals(66,staffProperty.getAvailableAppointments().size());
       assertEquals("2018 Jun 01 09:00", availableAppointments.get(0));
       assertEquals("2018 Jun 15 09:00", availableAppointments.get(10));
       assertEquals("2018 Jun 29 09:00", availableAppointments.get(20)); 
       assertEquals("2018 Jul 02 09:00", availableAppointments.get(21));
       assertEquals("2018 Jul 16 09:00", availableAppointments.get(31));
       assertEquals("2018 Jul 31 09:00", availableAppointments.get(42));
       assertEquals("2018 Aug 01 09:00", availableAppointments.get(43));
       assertEquals("2018 Aug 15 09:00", availableAppointments.get(53)); 
       assertEquals("2018 Aug 31 09:00", availableAppointments.get(65)); 
       
    }
    
    @Test
    public void testAddMonthlyAppointments(){
        staffProperty.addMonthlyAppointmentsBooked("2018 Jun 01 09:00", "Eric Nyugen");
        assertEquals(1, staffProperty.getJuneAppointmentsBooked().size());
     
        
        staffProperty.addMonthlyAppointmentsBooked("2018 Jun 15 09:00", "Steve Pellerin");
        assertEquals(2, staffProperty.getJuneAppointmentsBooked().size());
        assertEquals(2, staffProperty.getJuneAppointmentsMakers().size());
        assertEquals("2018 Jun 15 09:00", staffProperty.getJuneAppointmentsBooked().get(1));
        assertEquals("Steve Pellerin", staffProperty.getJuneAppointmentsMakers().get(1));
        
        staffProperty.addMonthlyAppointmentsBooked("2018 Jul 02 09:00", "Shaun Ganley");
        assertEquals(1, staffProperty.getJulyAppointmentsBooked().size());
        assertEquals("Shaun Ganley", staffProperty.getJulyAppointmentsMakers().get(0));
        
        staffProperty.addMonthlyAppointmentsBooked("2018 Aug 15 09:00", "David Penn");
        assertEquals("David Penn", staffProperty.getAugAppointmentsMakers().get(0));
        
        assertEquals(1, staffProperty.getAugAppointmentsBooked().size());
        assertEquals(2, staffProperty.getJuneAppointmentsBooked().size());
        assertEquals(1, staffProperty.getJulyAppointmentsBooked().size());
    }
    
    /*
     * Remove the first item, test, remove middle item, test, remove last item, test
    */
    @Test
    public void testUpdateAvailableAppointments(){
        assertEquals(66, staffProperty.getAvailableAppointments().size());
        staffProperty.updateAvailableAppointments("2018 Jun 01 09:00"); // Remove the first item
        assertEquals(65, staffProperty.getAvailableAppointments().size()); // Check size
        assertEquals("2018 Jun 04 09:00", availableAppointments.get(0)); // Check if the second item moved up
        staffProperty.updateAvailableAppointments("2018 Jul 16 09:00"); // Remove the middle item
        assertEquals(64, staffProperty.getAvailableAppointments().size()); // Check size
        assertEquals("2018 Jul 17 09:00", availableAppointments.get(30)); // Check if the item after middle item moved up
        staffProperty.updateAvailableAppointments("2018 Aug 31 09:00"); // Remove the middle item
        assertEquals(63, staffProperty.getAvailableAppointments().size()); // Check size
        
        staffProperty.updateAvailableAppointments("2018 Jun 01 09:00"); //removing the item not in the list
        assertEquals(63, staffProperty.getAvailableAppointments().size());
        
    }
    
    
    
}
