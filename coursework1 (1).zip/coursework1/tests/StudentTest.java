/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package coursework1;

import java.util.ArrayList;
import java.util.List;
import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;
import static org.junit.Assert.*;

/**
 *
 * @author minmm
 */
public class StudentTest {
    MyClasses classA;
    MyClasses classB;
    MyClasses classC;
    MyClasses classD;
    Student student;
    List<MyClasses> classList;
    
    public StudentTest() {
        classA = new MyClasses(new String[]{"JVP101","Java Programming 1", "G01", "Monday", "09:00", "11:00"});
        classB = new MyClasses(new String[]{"CDP101","C++ Programming", "G01", "Monday", "10:00", "12:00"});
        classC = new MyClasses(new String[]{"DTB101","Database", "G01", "Tuesday", "09:00", "11:00"});
        classD = new MyClasses(new String[]{"SYA101","System Architecture", "G01", "Tuesday", "12:00", "14:00"});
        classList = new ArrayList();
        student = new Student(new String[]{"Student", "S401", "Win", "Min", "Bishop St., Montreal, QC, Canada", "minwin@unimail.ca"}, classList);
    }
    
    

    /**
     * Test of addClassList method, of class Student.
     */
    @Test
    public void testAddClassList() {
        student.addClassList(classA);
        assertEquals(1, student.getClassList().size());
        assertEquals("Java Programming 1", student.getClassList().get(0).getClassName());
        student.addClassList(classB);
        assertEquals(2, student.getClassList().size());
        
        
    }

    
}
