/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package coursework1;

import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;
import static org.junit.Assert.*;

/**
 *
 * @author minmm
 */
public class VisitorTest {
    
    Visitor visitorA;
    Visitor visitorB;
    
    public VisitorTest() {
        visitorA = new Visitor("Visitor", "Steve Lough", "stevelough@myemail.com");
        visitorB = new Visitor("Visitor", "Adrian Pilot", "AdrianPilot@myemail.com");
    }
    

    /**
     * Test of getEmail method, of class Visitor.
     */
    @Test
    public void testGetEmail() {
        assertEquals("stevelough@myemail.com",visitorA.getEmail());
        assertEquals("AdrianPilot@myemail.com",visitorB.getEmail());
       
    }

    /**
     * Test of getFullName method, of class Visitor.
     */
    @Test
    public void testGetFullName() {
        assertEquals("Steve Lough", visitorA.getFullName());
        assertEquals("Adrian Pilot", visitorB.getFullName()); 
    }

    
    
}
