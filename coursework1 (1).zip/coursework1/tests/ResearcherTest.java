/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package coursework1;

import java.util.ArrayList;
import java.util.List;
import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;
import static org.junit.Assert.*;

/**
 *
 * @author minmm
 */
public class ResearcherTest {
    Researcher researcherA;
    private StaffProperty researcherProperty;
    private List<String> researcherAExpertise;
    
    public ResearcherTest() {
        researcherAExpertise = new ArrayList();
        researcherAExpertise.add("Data Analysis");
        StaffProperty researcherAStaffProperty = new StaffProperty("C01", researcherAExpertise, 3);
        researcherA = new Researcher(new String[]{"Researcher", "R101", "Corvec", "Shawn", "Bishop St., Montreal, QC, Canada", "shawncorvec@unimail.ca"}, researcherAStaffProperty);
        
    }
    

    /**
     * Test of getExpertise method, of class Researcher.
     */
    @Test
    public void testGetExpertise() {
        assertEquals(1, researcherA.getExpertise().size());
        assertEquals("Data Analysis", researcherA.getExpertise().get(0));
       
    }

    /**
     * Test of getStaffProperty method, of class Researcher.
     */
    @Test
    public void testGetStaffProperty() {
      assertEquals("C01", researcherA.getStaffProperty().getOffice());
    }

    /**
     * Test of printInfo method, of class Researcher.
     */
    @Test
    public void testPrintInfo() {
        
    }

    /**
     * Test of login method, of class Researcher.
     */
    @Test
    public void testLogin() {
       
    }
    
}
