/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package coursework1;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;
import static org.junit.Assert.*;

/**
 *
 * @author minmm
 */
public class KeyMemberMapCollectionTest {
        List<UniversityMember> professorList = new ArrayList();
        List<UniversityMember> lecturerList = new ArrayList();
        List<UniversityMember> researcherList = new ArrayList();
        List<UniversityMember> studentList = new ArrayList();
        KeyMemberMapCollection genericsCollection;
    public KeyMemberMapCollectionTest() {
      
    }

    /**
     * Test of setMemberMap method, of class KeyMemberMapCollection.
     */
    @Test
    public void testSetMemberMap() {
        List<String> researcherAExpertise = new ArrayList();
        researcherAExpertise.add("Data Analysis");
        Researcher researcherA = new Researcher(new String[]{"Researcher", "R101", "Corvec", "Shawn", "Bishop St., Montreal, QC, Canada", "shawncorvec@unimail.ca"}, new StaffProperty("C01", researcherAExpertise, 3));
        
        researcherList.add(researcherA);
        
        UniversityMemberDatabase.init(professorList, lecturerList, researcherList, studentList);
         UniversityMemberDatabase db = UniversityMemberDatabase.getInstance();
        
        assertEquals(1,db.getResearcherLastNames().size());
        assertEquals(1,db.getResearcherList().size());
        
        genericsCollection = new KeyMemberMapCollection(db.getResearcherLastNames(), db.getResearcherList());
        
        Map<String, Researcher> thatMap = genericsCollection.getMemberMap();
        assertEquals(1, thatMap.size());
        assertEquals(researcherA,thatMap.get("Corvec"));
        assertEquals("R101",thatMap.get("Corvec").getId());
        

        
        
    }
    
}
