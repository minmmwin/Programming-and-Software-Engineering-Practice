/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package coursework1;

import java.util.ArrayList;
import java.util.List;
import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;
import static org.junit.Assert.*;

/**
 *
 * @author minmm
 */
public class UniversityMemberDatabaseTest {
        List<UniversityMember> professorList = new ArrayList();
        List<UniversityMember> lecturerList = new ArrayList();
        List<UniversityMember> researcherList = new ArrayList();
        List<UniversityMember> studentList = new ArrayList();
        UniversityMember profA;
        UniversityMember profB;
        UniversityMember profC;
        UniversityMember lecturerA;
        UniversityMember researcherA;
        UniversityMember researcherB;
        UniversityMember studentA;
        
        
        UniversityMemberDatabase db;
        //UniversityMemberDatabase db1;
        
        public UniversityMemberDatabaseTest(){
            
        List<String> profAExpertises = new ArrayList<>();
        profAExpertises.add("Programming");
        profAExpertises.add("Data Analysis");
        List<String> profBExpertises = new ArrayList<>();
        profBExpertises.add("Security");
       
        profA = new Professor(new String[]{"Professor", "P101", "Smith", "Mike", "Guy St., Montreal, QC, Canada", "mikesmith@unimail.ca"}, new StaffProperty("A01", profAExpertises, 1), new ArrayList());
        profB = new Professor(new String[]{"Professor", "P102", "Smth", "Mike", "Guy St., Montreal, QC, Canada", "mikesmith@unimail.ca"}, new StaffProperty("A02", profBExpertises, 2), new ArrayList());
        profC = new Professor(new String[]{"Professor", "P103", "Boss", "Mike", "Guy St., Montreal, QC, Canada", "mikesmith@unimail.ca"}, new StaffProperty("A03", new ArrayList(), 3), new ArrayList());
        professorList.add(profA);
        professorList.add(profB);
        professorList.add(profC);
        
        List<String> lecturerAExpertise = new ArrayList();
        lecturerAExpertise.add("Artificial Intelligence");
        lecturerA = new Lecturer(new String[]{"Lecturer", "L101", "Game", "Joe", "Armnest St., Montreal, QC, Canada", "joegame@unimail.ca"}, new StaffProperty("B01", lecturerAExpertise, 3), new ArrayList());
        lecturerList.add(lecturerA);
        
        List<String> researcherAExpertise = new ArrayList();
        researcherAExpertise.add("Data Analysis");
        researcherA = new Researcher(new String[]{"Researcher", "R101", "Corvec", "Shawn", "Bishop St., Montreal, QC, Canada", "shawncorvec@unimail.ca"}, new StaffProperty("C01", researcherAExpertise, 3));
        researcherB = new Researcher(new String[]{"Researcher", "R102", "Wayne", "Kev", "Bishop St., Montreal, QC, Canada", "shawncorvec@unimail.ca"}, new StaffProperty("C01", researcherAExpertise, 3));
        researcherList.add(researcherA);
        researcherList.add(researcherB);
        
        studentA = new Student(new String[]{"Student", "S101", "Win", "Min", "Bishop St., Montreal, QC, Canada", "minwin@unimail.ca"}, new ArrayList());
        studentList.add(studentA);
        
        //db = UniversityMemberDatabase.getInstance(professorList, lecturerList, researcherList, studentList);
        UniversityMemberDatabase.init(professorList, lecturerList, researcherList, studentList);
        db = UniversityMemberDatabase.getInstance();
   }
   
   @Test
   public void testGetMemberExpertises(){
        assertEquals(3, db.getMemberExpertises(professorList).size());
        assertEquals("Programming", db.getMemberExpertises(professorList).get(0));
        assertEquals("Data Analysis", db.getMemberExpertises(professorList).get(1));
        assertEquals("Security", db.getMemberExpertises(professorList).get(2));
        
        assertEquals(1, db.getMemberExpertises(lecturerList).size());
        assertEquals("Artificial Intelligence", db.getMemberExpertises(lecturerList).get(0));
        
       assertEquals(2, db.getMemberExpertises(researcherList).size());
        //assertEquals("Data Analysis", db.getMemberExpertises(researcherList).get(0));
   }
   
   @Test
   public void testSetExpertiseMapWithMember(){
       assertEquals(4, db.getExpertiseMapAllStaffMembers().size());
       db.setExpertiseMapWithMember("UX", (StaffMember)profC);
       assertEquals(profC, db.getExpertiseMapAllStaffMembers().get("UX").get(0));
       assertEquals(5, db.getExpertiseMapAllStaffMembers().size());
       
       assertEquals(profA, db.getExpertiseMapAllStaffMembers().get("Programming").get(0));
       assertEquals(profA, db.getExpertiseMapAllStaffMembers().get("Data Analysis").get(0));
       assertEquals(profB, db.getExpertiseMapAllStaffMembers().get("Security").get(0));
       assertEquals(lecturerA, db.getExpertiseMapAllStaffMembers().get("Artificial Intelligence").get(0));
       assertEquals(researcherA, db.getExpertiseMapAllStaffMembers().get("Data Analysis").get(1));
       assertEquals(researcherB, db.getExpertiseMapAllStaffMembers().get("Data Analysis").get(2));
       
       
   }
   
   @Test
   public void testGetExpertiseListAll(){
       assertEquals(4, db.getExpertiseListAll().size());
       assertTrue(db.getExpertiseListAll().contains("Programming"));
       assertTrue(db.getExpertiseListAll().contains("Data Analysis"));
       assertTrue(db.getExpertiseListAll().contains("Security"));
       assertTrue(db.getExpertiseListAll().contains("Artificial Intelligence"));
   }
   
   @Test
   public void testContainsExpertise(){
       assertTrue(db.containsExpertise("Programming"));
       assertTrue(db.containsExpertise("Data Analysis"));
       assertTrue(db.containsExpertise("Security"));
       assertTrue(db.containsExpertise("Artificial Intelligence"));
       assertFalse(db.containsExpertise("Communication"));
       
   }
        
   @Test
   public void testGetMemberLastNames(){
        assertEquals(3, db.getMemberLastNames(professorList).size());
        assertTrue (db.containsName("Smith"));   
        assertTrue (db.containsName("Smth")); 
        assertTrue (db.containsName("Boss"));   
        assertFalse (db.containsName("Warren")); 
        
        assertEquals(2, db.getMemberLastNames(researcherList).size());
        //assertTrue (db.containsName("Corvec"));   
        
   }
   
   @Test
   public void testGetMemberIDs(){
        assertEquals(3, db.getMemberIDs(professorList).size());
        assertEquals(1, db.getMemberIDs(lecturerList).size());
        assertEquals(2, db.getMemberIDs(researcherList).size());
        assertEquals(1, db.getMemberIDs(studentList).size());
        //assertTrue (db.containsName("Corvec"));   
        
   }
        
  
    
    @Test
    public void testGetProfessorNameMap(){
        assertEquals(profA,db.getProfessorNameMap().get("Smith"));
        assertEquals(profB,db.getProfessorNameMap().get("Smth"));
        assertEquals(profC,db.getProfessorNameMap().get("Boss"));
    }
    
    @Test
    public void testGetLecturerNameMap(){
        assertEquals(lecturerA,db.getLecturerNameMap().get("Game"));
    }
    
    @Test
    public void testGetResearcherNameMap(){
       assertEquals(2,db.getResearcherNameMap().size());
       assertEquals(researcherA, db.getResearcherNameMap().get("Corvec"));
       assertEquals(researcherA.getId(), db.getResearcherNameMap().get("Corvec").getId());
    }
    
    @Test 
    public void testGetStudentNameMap(){
        assertEquals(1,db.getStudentNameMap().size());
        //System.out.println("Student: " + s.getId() + s.getFirstName() + s.getLastName() + s.getEmail() + s.getAddress()+ s.getClass() + s.toString());
        assertEquals(studentA,db.getStudentNameMap().get("Win"));
        assertEquals(studentA.getId(),db.getStudentNameMap().get("Win").getId());
        
    }
    
     @Test
    public void testGetProfessorIDMap(){
        assertEquals(profA.getLastName(),db.getProfessorIDMap().get("P101").getLastName());
        assertEquals(profB,db.getProfessorIDMap().get("P102"));
        assertEquals(profC,db.getProfessorIDMap().get("P103"));
    }
    
    @Test
    public void testGetLecturerIDMap(){
        assertEquals(lecturerA,db.getLecturerIDMap().get("L101"));
    }
    
    @Test
    public void testGetResearcherIDMap(){
       assertEquals(2,db.getResearcherIDMap().size());
       assertEquals(researcherA, db.getResearcherIDMap().get("R101"));
       assertEquals(researcherA.getLastName(), db.getResearcherIDMap().get("R101").getLastName());
    }
    
    @Test 
    public void testGetStudentIDMap(){
        assertEquals(1,db.getStudentIDMap().size());
        //System.out.println("Student: " + s.getId() + s.getFirstName() + s.getLastName() + s.getEmail() + s.getAddress()+ s.getClass() + s.toString());
        assertEquals(studentA,db.getStudentIDMap().get("S101"));
        assertEquals(studentA.getLastName(),db.getStudentIDMap().get("S101").getLastName());
        
    }
    
    
    
}
