
package coursework1;

/**
 * Visitor class implements AppointmentMaker
 * 
 */
public class Visitor implements AppointmentMaker {

    private String type;
    private String fullName;
    //private String firstName;
    private String email;
    
    public Visitor(String type, String fullName, String email) {
        this.type = type;
        this.fullName =  fullName;
        this.email = email;
        
    }
    
    public String getType(){
        return type;
    }
    
    /**
     * @return the email
     */
    public String getEmail() {
        return email;
    }

    /**
     * @return the fullName
     */
    public String getFullName() {
        return fullName;
    }

    @Override
    public boolean makeAppointment(StaffMember staff, String appointment) {
        boolean updateavailableAppointments = staff.getStaffProperty().updateAvailableAppointments(appointment);
        staff.getStaffProperty().addMonthlyAppointmentsBooked(appointment, new String(fullName + " " + email));
        
        return true;
    }
    
}
