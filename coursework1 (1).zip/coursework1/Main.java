
package coursework1;

import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Scanner;
import java.util.logging.Level;
import java.util.logging.Logger;

/*
 * Main creates two tasks by using Threads; taskA to createUniversity members, taskB to run MVC
 * 
 */
public class Main {

    
    public static void main(String[] args) {
        try {
            // Create the two tasks
            Thread taskA = new UniversityMemberCreationThread ("Running Thread A... Creating University Members");    
            Thread taskB = new RunMVCThread ("Running UI for login");       
            // run the two tasks
            taskA.start ();                                       
            taskA.join();
            
            taskB.start();
            taskB.join();
            
        } catch (InterruptedException ex) {
            Logger.getLogger(Main.class.getName()).log(Level.SEVERE, null, ex);
        }
        
       
            
    }
    
}
